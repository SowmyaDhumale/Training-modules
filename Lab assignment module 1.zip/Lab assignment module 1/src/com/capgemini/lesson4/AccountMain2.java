//4.2: Extend the functionality through Inheritanceand polymorphism (Maintenance)
//Inherit two classes Savings Account and Current Account from account class. Implement the following in the respective classes.
//a) Savings Account
//a. Add a variable called minimum Balance and assign final modifier.
//b. Override method called withdraw (This method should check for minimum balance and allow withdraw to happen)
//b) Current Account
//a. Add a variable called overdraft Limit
//b. Overridemethod called withdraw (checks whether overdraft limit is reached and returns a boolean value accordingly)


package com.capgemini.lesson4;

import java.util.Scanner;

public class AccountMain2
{

	public static void main(String[] args)
	{
		SavingAccount ac1 = new SavingAccount("Kathy", "serre", 50,  3000);
		System.out.println(ac1);
		CurrentAccount ac2 = new CurrentAccount("Smith", "serre", 45,  2000);
		System.out.println(ac2);
		String ans;
		Scanner sc = new Scanner(System.in);
	
		do
		{
			
			System.out.println("1. Deposit INR to Kathy Saving account.");
			System.out.println("2. Deposit INR to smith Current account.");
			System.out.println("3. Withdraw INR from Kathy Saving account.");
			System.out.println("4. Withdraw INR from smith Current account.");
			System.out.println("5. Display updated balances in both the account.");
			System.out.println("6. exit");
			System.out.println("enter ur choice");
			int choice = sc.nextInt();
			double bal;
			switch(choice)
			{
				case 1 : System.out.println("enter the amount which u want to deposit");
						 bal = sc.nextDouble();
						 ac1.deposit(bal);
						 break;
				case 2 : System.out.println("enter the amount which u want to deposit");
				 		 bal = sc.nextDouble();
				 		 ac2.deposit(bal);
						 break;
				case 3 : System.out.println("enter the withdrwal amount");
				 		 bal = sc.nextDouble();
						 boolean b = ac1.withdraw(bal);
						 if(b==false)
							 System.out.println("insufficient amount");
						 break;
				case 4 : System.out.println("enter the withdrwal amount");
		 		 		 bal = sc.nextDouble();
		 		 		 boolean bb = ac2.withdraw(bal);
		 		 		 if(bb==false)
				 			 System.out.println("insufficient amount");
				 		 break;
				case 5 : System.out.println(ac1);
						 System.out.println(ac2);
						 break;
				case 6 : System.exit(0);
			}
			System.out.println("Do you want to continue yes/no");
			ans = sc.next();

		} while (ans.equalsIgnoreCase("yes") || ans.equalsIgnoreCase("y"));

		
	}
}
