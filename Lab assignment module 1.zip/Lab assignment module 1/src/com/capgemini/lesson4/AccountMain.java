//4.1: Refer the case study 1in Page No: 5 and create Account Class as shown below in class diagram. 
//Ensure minimum balance of INR 500 in a bank account is available.
//a) Create Account for smith with initial balance as INR 2000 and for Kathy with initial balance as 3000.(accNum should be auto generated).
//b) Deposit 2000 INR to smith account.
//c) Withdraw 2000 INR from Kathy account.
//d) Display updated balances in both the account.
//e) Generate toString() method.

package com.capgemini.lesson4;

import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) 
	{
	
		Account ac1 = new Account("Kathy", "serre", 50,  3000);
		System.out.println(ac1);
		Account ac2 = new Account("Smith", "serre", 45,  2000);
		System.out.println(ac2);
		String ans;
		Scanner sc = new Scanner(System.in);
	
		do
		{
			
			System.out.println("1. Deposit 2000 INR to Kathy account.");
			System.out.println("2. Deposit 2000 INR to smith account.");
			System.out.println("3. Withdraw 2000 INR from Kathy account.");
			System.out.println("4. Withdraw 2000 INR from smith account.");
			System.out.println("5. Display updated balances in both the account.");
			System.out.println("6. exit");
			System.out.println("enter ur choice");
			int choice = sc.nextInt();
			switch(choice)
			{
				case 1 : ac1.deposit(2000);
						 break;
				case 2 : ac2.deposit(2000);
						 break;
				case 3 : boolean b = ac1.withdraw(2000);
						 if(b==false)
							 System.out.println("insufficient amount");
						 break;
				case 4 : boolean bb = ac2.withdraw(2000);
				 		 if(bb==false)
				 			 System.out.println("insufficient amount");
				 		 break;
				case 5 : System.out.println(ac1);
						 System.out.println(ac2);
						 break;
				case 6 : System.exit(0);
			}
			System.out.println("Do you want to continue yes/no");
			ans = sc.next();

		} while (ans.equalsIgnoreCase("yes") || ans.equalsIgnoreCase("y"));

	}

	}


