//4.1

package com.capgemini.lesson4;

public class Account extends Person {
	static int counter = 100;
	long accNum;
	double balance;
	Person accHolder;

	public Account(String firstName, String lastName, int age, double balance) {
		super(firstName, lastName, age);
		this.accNum = counter++;
		this.balance = balance;

	}

	public void deposit(double balance) {
		this.balance = this.balance + balance;
	}

	public boolean withdraw(double balance) {
		if ((this.balance - balance) > 500) {
			this.balance = this.balance - balance;
			return true;
		} else
			return false;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;

	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", age=" + age + "]";
	}

}
