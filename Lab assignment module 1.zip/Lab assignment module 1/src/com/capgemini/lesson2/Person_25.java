//2.5: Modify the above program, to accept only �M� or �F� as gender field values. Use Enumeration for implementing the same.
package com.capgemini.lesson2;

public class Person_25 {

	public enum Gender {
		m, f
	};

	String firstName;
	String lastName;
	Gender gender;
	String mobile;

	public Person_25() {
		super();
		this.firstName = null;
		this.lastName = null;
		this.gender=gender.m;
		this.mobile = null;

	}

	public Person_25(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;

	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Person Details:\n______________\n\nFirst Name: "
				+ getFirstName() + "\nLast Name: " + getLastName()
				+ "\nGender: " + getGender() + " ";

	}

	public void genderCheckMale(char ch) {
		
		setGender(gender.m);
		
	}

	public void genderCheckFemale(char ch) {
		
		setGender(gender.f);
		
	}
}
