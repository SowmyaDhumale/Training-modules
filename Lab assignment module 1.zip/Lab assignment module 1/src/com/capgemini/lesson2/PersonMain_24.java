//2.4: Modify Lab assignment 2.3 to accept phone number of a person. Create a newmethod to implement the same and also define method for displaying persondetails.
package com.capgemini.lesson2;

import java.util.Scanner;

public class PersonMain_24 {

	public static void main(String[] args) {

		Person_24 person = new Person_24("Yash", "Geel", 'M');
				//
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the mobile number");
		String number = sc.next();
		person.setMobile(number);
		person.display();
	}

}
