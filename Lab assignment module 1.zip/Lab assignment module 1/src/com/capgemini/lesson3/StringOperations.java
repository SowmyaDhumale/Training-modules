/*3.1: Create a method which can perform a particular String operation based on the user’s choice. The method should accept the String object and the user’s choice and return the output of the operation.
Options are
 Add the String to itself
 Replace odd positions with #
 Remove duplicate characters in the String
 Change odd characters to upper case*/

package com.capgemini.lesson3;

import java.util.Scanner;

public class StringOperations {

	String s;

	public void appendString(String str) {
		s = s.concat(str);
		System.out.println("new string is : " + s);
	}

	public void replaceString() {
		for (int i = 0; i < s.length(); i++) {
			if (i % 2 != 0) {
				char ch1 = s.charAt(i);
				char ch2 = '#';
				s = s.substring(0, i - 1) + "#" + s.substring(i, s.length());

			}
		}
		System.out.println("Updated String is :- " + s);
	}

	public void removeDuplicate() {
		int flag = 0, k = 0;
		char ch[] = s.toCharArray();
		String st = "";
		st = st + s.charAt(0);

		for (int i = 1; i < ch.length; i++) {
			flag = 0;
			for (int j = 0; j < st.length(); j++) {

				if (st.charAt(j) == ch[i]) {
					flag = 1;
				}
			}
			if (flag == 0) {
				st = st + ch[i];
			}

		}
		System.out.println("Updated String is :- " +st);

	}
	
	public void uppercaseString() 
	{
		char ch;
		String st = "";
		for(int i=0;i<s.length();i++)
		{
			
			if(i%2==0)
			{
				ch = s.toUpperCase().charAt(i);
				st = st + ch;
			}
			else
			{
				st = st + s.charAt(i);
			}
		}
		System.out.println("Updated String is :- " +st);
		
	}


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringOperations so = new StringOperations();

		String ans = null;

		do {
			System.out.println("enter the string");
			so.s = sc.next();
			System.out.println("1. Add the String to itself");
			System.out.println("2. Replace odd positions with #");
			System.out.println("3. Remove duplicate characters in the String");
			System.out.println("4. Change odd characters to upper case");
			System.out.println("5. Exit.");
			System.out.println("**ENTER YOUR CHOICE**");

			int choice = sc.nextInt();

			switch (choice) {
			
			case 1:	System.out.println("Enter the new string which you want to add");
					String str = sc.next();
					so.appendString(str);
					break;
			
			case 2: so.replaceString();
					break;
			
			case 3: so.removeDuplicate();
					break;
			
			case 4: so.uppercaseString();
					break;
			
			case 5: System.out.println("exit.!");
					System.exit(0);
			
			default:System.out.println("Invalid choice. Please enter the valid choice.");
					break;

			}
			System.out.println("Do you want to continue yes/no");
			ans = sc.next();

		} while (ans.equalsIgnoreCase("yes") || ans.equalsIgnoreCase("y"));

	}

	
}
