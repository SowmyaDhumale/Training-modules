//3.5: Create a method to accept product purchase date and warrantee period (in terms of months and years). Print the date on which warrantee of product expires.

package com.capgemini.lesson3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class WarranteeExpirationDate {

	public static void main(String[] args) 
	{	
		Scanner sc = new Scanner(System.in);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("enter the purchase  date in the dd/mm/yyyy format");
		String stDate = sc.next();
		LocalDate startdate = LocalDate.parse(stDate, formatter);
		System.out.println("enter the Warranty month and year mm/yy format");
		String enDate = sc.next();
		int year=0, month=0;
		for(int i=0;i<enDate.length();i++)
		{
			if(enDate.charAt(i)=='/')
			{
				year = Integer.parseInt(enDate.substring(i+1,enDate.length()));
				month = Integer.parseInt(enDate.substring(0,i));
			}
		}
	
		int y = startdate.getYear();
		int m = startdate.getMonthValue();
		int d= startdate.getDayOfMonth();
		y=y+year;
		m=m+month;
		if(m>12)
		{
			m = m-12;
			y= y+1;
			
		}
		
		System.out.println("Expiry Date is : - " + d + "/" + m + "/" + y);
		
		

}

}