//3.8 : Create a method that can accept an array of String objects and sort in alphabetical order.
//The elements in the left half should be completely in uppercase and the elements in the right half
//should be completely in lower case. Return the resulting array.
//Note: If there are odd number of String objects, then (n/2)+1 elements should be in UPPPERCASE

package com.capgemini.lesson3;

import java.util.Arrays;
import java.util.Scanner;
import java.util.SortedSet;

import javax.swing.SortOrder;

public class StringSorting {
	
	public void stringSort(String[] str, int n)
	{ 	
		int no = n;
		String temp="";
		for(int i=0;i<n;i++)
		{
			for(int j=i;j<n;j++)
			{
				if(str[i].compareTo(str[j])>0)
				{
					temp = str[i];
					str[i] = str[j];
					str[j] = temp;
				}
			}
		}
		
		
		char ch;
		
		if(n%2==0)
		{
			n=n/2;
		}
		else
		{
			n= n/2+1;
		}
		
		for(int i=0;i<no;i++)
		{
			
			
			if(i<n)
			{
				str[i] = str[i].toUpperCase();
				
			}
			else
			{
				str[i] = str[i].toLowerCase();
				
			}
		}
		
		
		
		for(int i=0;i<no;i++)
			System.out.println(str[i]);
	}
	

	public static void main(String[] args) {
		
		StringSorting sort = new StringSorting();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter total number of string that you want to enter");
		int n = sc.nextInt();
		String str[] = new String[n] ;
		for(int i=0;i<n;i++)
		{
			System.out.println("enter the string");
			str[i]=sc.next();
		}
		
		
		sort.stringSort(str,n);
		
	}

	
}
