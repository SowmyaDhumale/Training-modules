//9.3: Enhance the lab assignment 6.3 by adding functionality in service class to write employee objects into a File. Also read employee details from file and display the same in console. Analyze the output of the program.

package com.capgemini.lesson9;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

import com.capgemini.lesson5.eis.bean.Employee;

public class EmployeeFile {

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		Employee emp[] = new Employee[8];
		emp[1] = new Employee(101, "yash", 50000, "Manager");
		emp[2] = new Employee(102, "ritvik", 35000, "Programmer");
		emp[3] = new Employee(103, "rahul", 12000, "System Associate");
		emp[4] = new Employee(104, "jai", 11000, "System Associate");
		emp[5] = new Employee(105, "shreya", 35000, "Programmer");
		emp[6] = new Employee(106, "kamal", 4000, "Clerk");
		emp[7] = new Employee(107, "krishna", 10000, "System Associate");
		
		
		File file1 = new File("D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson9\\Employee.txt");
		File fout = new File("D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson9\\Employee.txt");
		FileOutputStream toFile ;
		toFile = new FileOutputStream("D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson9\\Employee.txt");
		String temp = "";
		System.out.println("Writing data into files........");
		for(int i =1;i<=7;i++)
		{
			temp = "";
			temp = temp + emp[i].getEmpId();
			for(int j=0;j<temp.length();j++)
			{
				
				int k = temp.charAt(j);
				toFile.write(k);
			}
			toFile.write(32);
			
			temp="";
			temp = temp + emp[i].getEmpName();
			for(int j=0;j<temp.length();j++)
			{
				
				int k = temp.charAt(j);
				toFile.write(k);
			}
			toFile.write(32);
			temp="";
			temp = temp + emp[i].getEmpDesignation();
			for(int j=0;j<temp.length();j++)
			{
				
				int k = temp.charAt(j);
				toFile.write(k);
			}
			toFile.write(32);
			
			toFile.write(10);
			
		}
		
		System.out.println("Retriving data from the file");
		Scanner sc = new Scanner(file1);
		for(int i=1; i <=7 ; i++)
		{
			System.out.println(sc.nextLine());
			Thread.sleep(1000);
		}

	}

}
