//5.3: Refer the problem statement 4.1. Modify account class as abstract class and declare withdraw method.

package com.capgemini.lesson5.eis.service;

import java.util.Scanner;

import com.capgemini.lesson5.eis.bean.Account;

public class AccountAbstractMain extends Account
{

	long balance;
	
	@Override
	public boolean withdrawl(double balance)
	{
		
		if((this.balance-balance)<500)
			return false;
		else
			return true;
		
	}

	
	
	public static void main(String[] args) 
	{
		AccountAbstractMain am = new AccountAbstractMain();
		am.balance = 1000;
		System.out.println("current balance is : - " + am.balance);
		System.out.println("Enter the amount you want u withdrawl");
		Scanner sc = new Scanner(System.in);
		long balance = sc.nextLong();
		if(!am.withdrawl(balance))
		{
			System.out.println("Insufficient balance");
			
		}
		else
		{
			System.out.println("amount withdrawled succesfully and current balance is :- " + (am.balance-balance) );
		}
		
		
		
		
	}

	
}
