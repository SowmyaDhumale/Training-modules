//5.3

package com.capgemini.lesson5.eis.bean;



public abstract class Account
{

	public abstract boolean withdrawl(double balance);
	
}
