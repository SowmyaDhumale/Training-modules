//5.1
package com.capgemini.lesson5.eis.pl;

import com.capgemini.lesson5.eis.bean.Employee;

public interface EmployeeServiceInterface 
{
	public void insuranceCalc(Employee emp);
}
