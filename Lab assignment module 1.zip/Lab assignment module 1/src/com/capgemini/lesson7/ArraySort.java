//7.1: Create a method which accepts an integer array, reverse the numbers in the array and returns the resulting array in sorted order.

package com.capgemini.lesson7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import javax.sound.sampled.ReverbType;

public class ArraySort 
{
	public int getSorted(int[] array)
	{
		
		for(int i=0;i<array.length;i++)
		{
			String reverse = "";
			String temp = Integer.toString(array[i]);
			 for(int j = temp.length()-1 ; j>=0;j--)
			 {
				 reverse = reverse + temp.charAt(j);
			 }
			 array[i] = Integer.parseInt(reverse); 
		}
		Arrays.sort(array);
		for(int i=0;i<array.length;i++)
		{
			System.out.println(array[i]);
		}
		return 1;
	}
	
	public static void main(String[] args) 
	{
		String ans;
		Scanner sc = new Scanner(System.in);
		ArraySort as = new ArraySort();
		
		System.out.println("enter the total no of elements u want to enter.");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("enter the numbers");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		as.getSorted(arr);

	}
}
