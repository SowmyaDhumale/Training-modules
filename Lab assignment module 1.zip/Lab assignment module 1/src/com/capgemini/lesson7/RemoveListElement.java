//7.3: Create a method which can remove a List from another List

package com.capgemini.lesson7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RemoveListElement {

	public ArrayList<String> removeElements(ArrayList<String> list1, ArrayList<String> list2)
	{
		
		 list1.removeAll(list2);
		
		return list1;
		
	}
	
	
	public static void main(String[] args)
	{
		RemoveListElement rl = new RemoveListElement();
		ArrayList<String> list1 = new ArrayList<String>();
		ArrayList<String> list2 = new ArrayList<String>();
		ArrayList<String> list3 = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 5 elements in first list");
		for(int i=0;i<5;i++)
		{
			list1.add(sc.next());
		}
		System.out.println("enter 5 elements in second list");
		for(int i=0;i<5;i++)
		{
			list2.add(sc.next());
		}
		
		list3 = rl.removeElements(list1, list2);
		System.out.println(list3);
		
	}

}
