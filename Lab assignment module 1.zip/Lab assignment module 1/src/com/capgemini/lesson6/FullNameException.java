//6.1: Modify the Lab assignment 2.3 to validate the full name of an employee. Create and throw a user defined exception if firstName and lastName is blank.

package com.capgemini.lesson6;

import java.util.Scanner;



 class myException extends Exception
 {
	 public String getMessage()
		{
			return "Please enter some values for firstname and lastname";
		}

}	
 
 public class FullNameException 
 {
	 public static void main(String[] args) throws myException 
	 {
		 String firstName="yash";
		 String lastName="";
		
		String fullName= checkFullName(firstName,lastName);
		 System.out.println("full name is:- " + fullName);
		 
	}
	 public static String checkFullName(String fName, String lName) throws myException
	 {
		 if(fName.isEmpty()&&lName.isEmpty())
		 {
			 try {
				throw new myException();
				
			} catch (myException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 else
		 {
			 return fName + " " + lName;
		 }
		 return "";
	 }
 }