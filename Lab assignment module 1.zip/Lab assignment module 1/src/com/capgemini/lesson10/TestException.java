//10.2.2: Consider the lab assignment 6.3 from Exception Handling Lab. Create a new class ExceptionCheck.javawhich handles an exception. Write a test case to verify if the exception is being handled correctly.

package com.capgemini.lesson10;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestException 
{

	@Test(expected = myException2.class)
	public void exceptionTest() throws myException2
	{
		ExceptionCheck ec = new ExceptionCheck();
		assertEquals("1000", ExceptionCheck.sal(1000));
	}

	@Test(expected = myException2.class)
	public void exceptionTest1() throws myException2
	{
		ExceptionCheck ec = new ExceptionCheck();
		assertEquals("1000", ExceptionCheck.sal(12));
	}

}
