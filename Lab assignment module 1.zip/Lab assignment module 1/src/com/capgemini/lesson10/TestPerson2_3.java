//10.2.1: Consider the Person class created in lab assignment 2.3. This class has some members and corresponding setter and getter methods. Write test case to check the functionality of getter methods and displaydetails method.

package com.capgemini.lesson10;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.lesson2.Person;

public class TestPerson2_3 
{
	@Test
	public void checkFirstName()
	{
		Person per = new Person();
		per.setFirstName("yash");
		assertEquals("yash", per.getFirstName());
	}
	
	@Test
	public void checkLirstName()
	{
		Person per = new Person();
		per.setLastName("geel");
		assertEquals("geel", per.getLastName());
	}
	
	@Test
	public void checkGender()
	{
		Person per = new Person();
		per.setGender('m');
		assertEquals('m', per.getGender());
	}
	
	@Test
	public void checkFullName()
	{
		Person per = new Person("yash", "geel", 'm');
		assertEquals("Person Details:\n______________\n\nFirst Name: "
				+ "yash" + "\nLast Name: " + "geel"
				+ "\nGender: " + 'm' + " ", per.toString());
	}
	
	
}
