//11.1
package com.capgemini.lesson11.lambda;

public interface ExponentialInterface_11_1 
{
	public abstract double exp(int x, int y);

}
